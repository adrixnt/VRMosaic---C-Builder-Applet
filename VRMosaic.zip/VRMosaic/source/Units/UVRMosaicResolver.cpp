
#include <UVRMosaicResolver.h>

//#include <System.Generics.Collections.hpp>

//#include <UVRGenListUtilsClass.hpp>

//#include <UVRListUtils.hpp>

#include <UVRMosaicListUtils.h>


	static
	int __fastcall CompareMosaicMatrix (
		TVRMosaicMatrix * aMatA,
		TVRMosaicMatrix * aMatB
	) {
		int aCount = aMatA->Count();
		int aIndex = 0;
		while (aIndex < aCount) {

			int aValueA = aMatA->Data (aIndex);
			int aValueB = aMatB->Data (aIndex);

			if (aValueA > aValueB)
				return (+1);
			else
			if (aValueA < aValueB)
				return (-1);

			++ aIndex;
		}
		return (0);
	}

	static
	int __fastcall _CompareMosaicMatrix (
		void * aPtrA,
		void * aPtrB
	) {
		return CompareMosaicMatrix (
			(TVRMosaicMatrix *) aPtrA,
			(TVRMosaicMatrix *) aPtrB
		);
	}

	static int __fastcall ManhattanCompare (void * aItem1, void * aItem2)
	{
		TVRMosaicSolverNode * aNode1 = (TVRMosaicSolverNode *) aItem1;
		TVRMosaicSolverNode * aNode2 = (TVRMosaicSolverNode *) aItem2;
		// get data
		int aManhattan1 = aNode1->Matrix()->ComputeManhattan();
		int aManhattan2 = aNode2->Matrix()->ComputeManhattan();
      	// compare
		if (aManhattan1 < aManhattan2)
			return (-1);
		else
		if (aManhattan1 > aManhattan2)
			return (+1);
		else
		//if (aManhattan1 == aManhattan2)
			return (0);
	}


	static
	bool __fastcall TryToAddNewMatrixNodeToTree (
		TList * aSignaturesList,
		TList * aGlobalStack,
		TList * aTreeList,
		TVRMosaicSolverNode * aOldNode,
		TVRMosaicMatrix * aNewMatrix
	) {

		int aParentNodeIndex = aOldNode->NodeIndex();

		bool shouldAddNode = true;

		int aKeyInsIndex = BinSearchList (
			aSignaturesList,
			aNewMatrix,
			_CompareMosaicMatrix
		);

		if ( IsListItemIndexValid (aSignaturesList, aKeyInsIndex) ) {

			TVRMosaicMatrix * aMatrix = (TVRMosaicMatrix *) ( aSignaturesList->Items [aKeyInsIndex] );

			if ( CompareMosaicMatrix (aNewMatrix, aMatrix) == 0 )

				shouldAddNode = false;

		}

		if (shouldAddNode) {

			TVRMosaicSolverNode * aNewNode = NULL;

			try {
				aNewNode = new TVRMosaicSolverNode();

				aNewNode->ParentNodeIndex (aParentNodeIndex);
				aNewNode->NodeIndex (aTreeList->Count);
				aNewNode->Matrix (aNewMatrix);
				// done
			} catch (...) {
				// could not create node
				delete aNewMatrix;
				//aNewMatrix = NULL;
				throw; //raise again
			}

			try {
				//add aNewNode to this.theNodesTree
				aTreeList->Add (aNewNode);
				// done
			} catch (...) {
				delete aNewNode;
				throw; //raise again
			}

			InsertDupsListOrderedItem (aGlobalStack, aNewNode, ManhattanCompare);

			// insert signature
			aSignaturesList->Insert (aKeyInsIndex, aNewMatrix);

		}
		else
			delete aNewMatrix;

		return shouldAddNode;
	}


	// generate successors of a node

	static
	void __fastcall GenerateSuccessorsOfNode (
		TList * aSignaturesList,
		TList * aGlobalStack,
		TList * aTreeList,
		TVRMosaicSolverNode * aNode
	) {

		if (aNode->Matrix()->CanSlideCellUp()) {

			//TVRMosaicMatrix * aNewMatrix = new TVRMosaicMatrix();
			TVRMosaicMatrix * aNewMatrix = aNode->Matrix()->Clone();
			//aNewMatrix->CopyFrom (aNode->Matrix());

			aNewMatrix->SlideCellUp();

			bool aNodeAdded = TryToAddNewMatrixNodeToTree (
				aSignaturesList,
				aGlobalStack,
				aTreeList,
				aNode, // the old node
				aNewMatrix // the new node matrix
			);
		}

		if (aNode->Matrix()->CanSlideCellDown()) {

			//TVRMosaicMatrix * aNewMatrix = new TVRMosaicMatrix();
			TVRMosaicMatrix * aNewMatrix = aNode->Matrix()->Clone();
			//aNewMatrix->CopyFrom (aNode->Matrix());

			aNewMatrix->SlideCellDown();

			bool aNodeAdded = TryToAddNewMatrixNodeToTree (
				aSignaturesList,
				aGlobalStack,
				aTreeList,
				aNode, // the old node
				aNewMatrix // the new node matrix
			);
		}

		if (aNode->Matrix()->CanSlideCellLeft()) {

			//TVRMosaicMatrix * aNewMatrix = new TVRMosaicMatrix();
			TVRMosaicMatrix * aNewMatrix = aNode->Matrix()->Clone();
			//aNewMatrix->CopyFrom (aNode->Matrix());

			aNewMatrix->SlideCellLeft();

			bool aNodeAdded = TryToAddNewMatrixNodeToTree (
				aSignaturesList,
				aGlobalStack,
				aTreeList,
				aNode, // the old node
				aNewMatrix // the new node matrix
			);
		}

		if (aNode->Matrix()->CanSlideCellRight()) {

			//TVRMosaicMatrix * aNewMatrix = new TVRMosaicMatrix();
			TVRMosaicMatrix * aNewMatrix = aNode->Matrix()->Clone();
			//aNewMatrix->CopyFrom (aNode->Matrix());

			aNewMatrix->SlideCellRight();

			bool aNodeAdded = TryToAddNewMatrixNodeToTree (
				aSignaturesList,
				aGlobalStack,
				aTreeList,
				aNode, // the old node
				aNewMatrix // the new node matrix
			);
		}

	}



	static void __fastcall ClearTreeNodesList (TList * aTreeList)
	{
		while (aTreeList->Count > 0) {
			TVRMosaicSolverNode * aNode = (TVRMosaicSolverNode *) aTreeList->Items [0];
			delete aNode;
			aTreeList->Delete (0);
		}
	}


	//static
	void __fastcall TVRMosaicResolver::Resolve (
		TVRMosaicResolver * aThread,
		TVRMosaicForm * aMosaicForm,
		TVRMosaicMatrix * aStartingMatrix
	) {

		TList * aTreeList = new TList();
		try {

			TVRMosaicSolverNode * aRootNode = NULL;

			TVRMosaicMatrix * aRootMatrix = aStartingMatrix->Clone();
			try {
				// create root node
				//TVRMosaicSolverNode *
				aRootNode = new TVRMosaicSolverNode();
				aRootNode->ParentNodeIndex (-1);
				aRootNode->NodeIndex (0);
				aRootNode->Matrix (aRootMatrix);
				// done
			} catch (...) {
				delete aRootMatrix;
				throw; //raise again
			}

			try {
				// add root node
				aTreeList->Add (aRootNode);
				// done
			} catch (...) {
				delete aRootNode;
				throw; //raise again
			}

         	TVRMosaicSolverNode * aFoundNode = NULL;

			TList * aSignaturesList = new TList();

			try {

			//int aNodeIndex = 0;

			TList * aGlobalStack = new TList();

			// show progress form
			aThread->ShowResolverProgressForm();

			try {

				int aAnalyzedMovesCount = 0;

				// push the root node into the global stack
				aGlobalStack->Insert (0, aRootNode);

				aSignaturesList->Insert (0, aRootNode->Matrix());

				while (true) {

					if (aGlobalStack->Count <= 0) break;

					// Thread -- test for termination
					if (aThread != NULL) {
						if (aThread->CheckTerminated())
							 break;
						//end if
					}

					// sort the global stack
					//aGlobalStack->Sort (ManhattanCompare);

					//TVRMosaicSolverNode * aNode = (TVRMosaicSolverNode *) aTreeList->Items [aNodeIndex];

					// pop a node from the global stack

					TVRMosaicSolverNode * aNode = (TVRMosaicSolverNode *) aGlobalStack->Items [0];
					aGlobalStack->Delete (0);

					++ aAnalyzedMovesCount;

					// show feedback
					if (aMosaicForm->IsWantResolverUpdates()) {
						if ((aGlobalStack->Count % aMosaicForm->GetResolverUpdateMovesCount()) == 0) {
							//aMosaicForm->PrintMatrix (aNode->Matrix());
							aThread->PrintMatrix (aNode->Matrix());
						}
					}

					// print feedback
					aThread->PrintResolverFeedback (
						aTreeList->Count,
						aAnalyzedMovesCount
					);

					// if aNode.Matrix.Solved() then break;
					if (aNode->Matrix()->IsMosaicDone()) {
						aFoundNode = aNode;
						break;
					}

					GenerateSuccessorsOfNode (
						aSignaturesList,
						aGlobalStack,
						aTreeList,
						aNode
					);

					//++ aNodeIndex;

				} // repeat

			} __finally {
				//aGlobalStack->Clear();
				delete aGlobalStack;
				//aGlobalStack = NULL;
				// hide progress form
				aThread->HideResolverProgressForm();
			}

			} __finally {
				delete aSignaturesList;
			}

			if (aFoundNode != NULL) {
				// ShowMessage ("FOUND");
				aThread->SolutionFound();
			}

			// aNodeIndex is the node index of the found solution !!

			if (aFoundNode != NULL) {

			// create final array
			DynamicArray<int> final;
			final.Length = 0;

			int aParentIndex = aFoundNode->NodeIndex();

			while (aParentIndex >= 0) {

				// final.Add (aParentIndex)
				final.Length = final.Length + 1;
				final [final.Length - 1] = aParentIndex;

				// aNode = get tree node at [aParentIndex]
				TVRMosaicSolverNode * aNode = (TVRMosaicSolverNode *) aTreeList->Items [aParentIndex];

				aParentIndex = aNode->ParentNodeIndex();

			} // loop

			// reverse final array
			{
				int j = final.Length - 1;
				int i = 0;
				while (i < j) {

					// swap final[i] <==> final[j] !!
					int tmp = final [i];
					final [i] = final [j];
					final [j] = tmp;

					++i;
					--j;
				}
			}

			// show moves count
			aThread->ShowMovesCount (final.Length);

			// print results in reverse order
			{
				int aCount = final.Length;
				int aIndex = 0;
				while (aIndex < aCount) {

					// Thread -- test for termination
					if (aThread != NULL) {
						if (aThread->CheckTerminated())
							 break;
						//end if
					} // end if

					// wait ...
					aThread->WaitForMoveAllowed();

					TVRMosaicSolverNode * aNode =
						(TVRMosaicSolverNode *) aTreeList->Items [ final [ aIndex ] ];

					TVRMosaicMatrix * aMatrix = aNode->Matrix();

					// print matrix
					aThread->PrintMatrix (aMatrix);
					//aMosaicForm->PrintMatrix (aMatrix);

					// delay as needed
					TThread::Sleep (aMosaicForm->GetResolverMovesDelay());

					++ aIndex;

				} // repeat

				aThread->PrintMatrix (aFoundNode->Matrix());

				aThread->SolutionDone();
			}

            } // if

		} __finally {
			try {
				ClearTreeNodesList (aTreeList);
			} catch (...) {
				// eat
			}
			delete aTreeList;
		}

	}


	// constructor
	__fastcall TVRMosaicResolver::TVRMosaicResolver() :
		TThread (true)
	{
	}


	void __fastcall TVRMosaicResolver::Execute() // virtual;
	{
		try {
			try {
				Resolve (
					this,
					this->theMosaicForm,
					this->theMosaicForm->GetMosaicMatrix()
				);
			} __finally {
				TVRMosaicForm * aMosaicForm = this->theMosaicForm;
				this->Synchronize (
					[aMosaicForm]() -> void {
						aMosaicForm->SetResolverAutomaticMoveStep ( false );
						aMosaicForm->SetResolverAutomaticMoves ( false );
					}
				);
			}
		} catch (...) {
			this->Synchronize (
				[]() -> void {
					ShowMessage ("ERROR");
				}
			);
		}
	}

	void __fastcall TVRMosaicResolver::PrintMatrix (TVRMosaicMatrix * aMatrix)
	{
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm, aMatrix]() -> void {
				aMosaicForm->PrintMatrix (aMatrix);
			}
		);
	}

	void __fastcall TVRMosaicResolver::ShowResolverProgressForm()
	{
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm]() -> void {
				aMosaicForm->ShowResolverProgressForm();
			}
		);
	}

	void __fastcall TVRMosaicResolver::HideResolverProgressForm()
	{
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm]() -> void {
				aMosaicForm->HideResolverProgressForm();
			}
		);
	}

	void __fastcall TVRMosaicResolver::PrintResolverFeedback(
		int aGeneratedMovesCount,
		int aAnalyzedMovesCount
	) {
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm, aGeneratedMovesCount, aAnalyzedMovesCount]() -> void {
				aMosaicForm->PrintResolverFeedback (
					aGeneratedMovesCount,
					aAnalyzedMovesCount
				);
			}
		);
	}

	void __fastcall TVRMosaicResolver::SolutionFound()
	{
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm]() -> void {
				aMosaicForm->SolutionFound();
			}
		);
	}

	void __fastcall TVRMosaicResolver::SolutionDone()
	{
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm]() -> void {
				aMosaicForm->SolutionDone();
			}
		);
	}

	void __fastcall TVRMosaicResolver::ShowMovesCount (int aMovesCount)
	{
		String aMessage = "";
		aMessage = aMessage +
			"Solution Found" + "\r\n" + "\r\n"
			"Moves: " + IntToStr (aMovesCount) + "\r\n" + "\r\n" +
			"press the Play button to start reordering ..."
		;
		this->Synchronize (
			[aMessage]() -> void {
				ShowMessage (
					aMessage
				);
			}
		);
	}


	void __fastcall TVRMosaicResolver::WaitForMoveAllowed()
	{
		while (true) {
			if (this->CheckTerminated()) break;
			if (this->theMosaicForm->IsResolverAutomaticMoves()) break;
			if (this->theMosaicForm->IsResolverAutomaticMoveStep()) break;
			// else wait ...
		}
		// reset single move indicator
		TVRMosaicForm * aMosaicForm = this->theMosaicForm;
		this->Synchronize (
			[aMosaicForm]() -> void {
				aMosaicForm->SetResolverAutomaticMoveStep ( false );
			}
		);
	}

