
#include <stddef.h>

#include <UVRMosaicSolverNode.h>

	// constructor

	TVRMosaicSolverNode :: TVRMosaicSolverNode() :
		theParentNodeIndex (0),
      theNodeIndex (0),
      theMatrix (NULL)
	{}

	// destructor

	TVRMosaicSolverNode :: ~ TVRMosaicSolverNode()
	{
		this->Matrix (NULL);
	}

	// parent node index

	int TVRMosaicSolverNode :: ParentNodeIndex() const
	{
		return this->theParentNodeIndex;
	}

	void TVRMosaicSolverNode :: ParentNodeIndex (int aIndex)
	{
		this->theParentNodeIndex = aIndex;
	}

	// node index

	int TVRMosaicSolverNode :: NodeIndex() const
	{
		return this->theNodeIndex;
	}

	void TVRMosaicSolverNode :: NodeIndex (int aIndex)
	{
		this->theNodeIndex = aIndex;
	}

	// matrix

	TVRMosaicMatrix * TVRMosaicSolverNode :: Matrix() const
	{
		return this->theMatrix;
	}

	void TVRMosaicSolverNode :: Matrix (TVRMosaicMatrix * aMatrix)
	{
		TVRMosaicMatrix * aOldMatrix = this->Matrix();
		if (aOldMatrix != aMatrix) {
			this->theMatrix = aMatrix;
			delete aOldMatrix;
		}
	}
