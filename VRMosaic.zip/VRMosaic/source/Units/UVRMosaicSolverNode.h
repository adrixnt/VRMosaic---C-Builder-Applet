
#ifndef __UVRMosaicSolverNodeH__

#define __UVRMosaicSolverNodeH__

#include <matrixm.h>

	class TVRMosaicSolverNode
	{

		// fields

		private: int theParentNodeIndex;

		private: int theNodeIndex;

		private: TVRMosaicMatrix * theMatrix;

		// constructor

		public: TVRMosaicSolverNode();

		// destructor

		public: ~ TVRMosaicSolverNode();

		// paren node index

		public: int ParentNodeIndex() const;
		public: void ParentNodeIndex (int aIndex);

		// node index

		public: int NodeIndex() const;
		public: void NodeIndex (int aIndex);

		// matrix

		public: TVRMosaicMatrix * Matrix() const;
		public: void Matrix (TVRMosaicMatrix * aMatrix);


	}; // class

#endif