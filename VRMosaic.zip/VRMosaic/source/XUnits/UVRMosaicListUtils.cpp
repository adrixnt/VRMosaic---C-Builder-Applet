//---------------------------------------------------------------------------

#pragma hdrstop

#include "UVRMosaicListUtils.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)


	bool __fastcall IsListItemIndexValid (TList * aList, int aIndex)
	{
		return ( (aIndex >= 0) && (aIndex < aList->Count) );
	}

	bool __fastcall IsListInsertIndexValid (TList * aList, int aIndex)
	{
		return ( (aIndex >= 0) && (aIndex < (aList->Count + 1)) );
	}


	// binary search

	int __fastcall BinSearchList (
		TList * aList,
		void * aItemToSearch,
		TListSortCompare aCompareFunc
	) {
		int aLoIndex = 0;
		int aHiIndex = aList->Count - 1;
		while (aLoIndex <= aHiIndex) {

			int aMidIndex = (aLoIndex + aHiIndex) / 2;

			void * aItem = aList->Items [aMidIndex];

			int aCompResult = aCompareFunc (aItemToSearch, aItem);

			if (aCompResult == 0) {
				// found !!
				return aMidIndex;
				// exit
			}

			if (aCompResult < 0)

				aHiIndex = aMidIndex - 1;

			else

				aLoIndex = aMidIndex + 1;

			// repeat
		}
		return aLoIndex;
	}


	// ordered insert

	int __fastcall InsertListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc,
		DuplicatesMode aDuplicatesMode
	) {
		int aInsIndex = BinSearchList (
			aList,
			aItemToInsert,
			aCompareFunc
		);

		if (aDuplicatesMode != allowDuplicates) {
			if ( IsListItemIndexValid (aList, aInsIndex) ) {
				void * aStoredItem = aList->Items [aInsIndex];
				int aCompResult = aCompareFunc (aItemToInsert, aStoredItem);
				if (aCompResult == 0) {
					if (aDuplicatesMode == doNotAllowDuplicates)
						throw new Exception ("duplicates not allowed");
					// else
					// duplicates are ignored
					return aInsIndex;
					// exit
				}
			}
		}

		aList->Insert (aInsIndex, aItemToInsert);

		return aInsIndex;
	}


	int __fastcall InsertUniqueListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc
	) {
		return InsertListOrderedItem (
			aList,
			aItemToInsert,
			aCompareFunc,
			doNotAllowDuplicates
		);
	}

	int __fastcall InsertDupsListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc
	) {
		return InsertListOrderedItem (
			aList,
			aItemToInsert,
			aCompareFunc,
			allowDuplicates
		);
	}
