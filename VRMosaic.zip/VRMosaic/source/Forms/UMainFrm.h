//---------------------------------------------------------------------------
#ifndef UMainFrmH
#define UMainFrmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <AppEvnts.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>

//#include <vcl/dstring.h>

#include <System.Contnrs.hpp>
#include <System.Generics.Collections.hpp>

#include <matrixm.h>
#include <Vcl.Samples.Spin.hpp>

#include <UShowProgressFrm.h>
#include <Vcl.Graphics.hpp>

//---------------------------------------------------------------------------
class TVRMosaicForm : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TPanel *Panel2;
	TPanel *Panel3;
	TPanel *Panel4;
	TPanel *Panel5;
	TPanel *Panel6;
	TBitBtn *theShuffleTableBtn;
	TStaticText *StaticText1;
	TPanel *Panel7;
	TPanel *theMosaicContainerPane;
	TPanel *theVRMosaicPanel;
	TStaticText *StaticText2;
	TStaticText *StaticText3;
	TBitBtn *theNewTableBtn;
	TPanel *Panel8;
	TBitBtn *theAboutBtn;
	TBitBtn *theCloseFormBtn;
	TStaticText *StaticText4;
	TApplicationEvents *myApplicationEvents;
	TMainMenu *theMainMenu;
	TMenuItem *theFileMenu;
	TMenuItem *theCloseApplicMenuItem;
	TMenuItem *theFormatMenu;
	TMenuItem *theSelectMosaicFontMenuItem;
	TMenuItem *theHelpMenu;
	TMenuItem *theAboutThisApplicMenuItem;
	TFontDialog *theMosaicFontDialog;
	TBitBtn *theSelectMosaicTabFontBitBtn;
	TMenuItem *N1;
	TMenuItem *theShowWinCardMenuItem;
	TOpenDialog *theVisualStyleThemeFileOpenDialog;
	TMenuItem *theVisualStyleMenu;
	TMenuItem *theOpenVisualStyleFileMenuItem;
	TMenuItem *theSetDefaultVisualStyleMenuItem;
	TBitBtn *theResolveMosaicBitBtn;
	TSpinEdit *theTabColSizeTxt;
	TSpinEdit *theTabRowSizeTxt;
	TBitBtn *theStopResolverBitBtn;
	TImage *theResolverThreadRunningIndicatorImage;
	TCheckBox *theWantResolverUpdatesCheckBox;
	TStaticText *StaticText5;
	TSpinEdit *theUpdateMovesCountSpinEdit;
	TStaticText *StaticText6;
	TStaticText *StaticText7;
	TSpinEdit *theResolverMovesDelaySpinEdit;
	TBitBtn *thePerformResolverSingleMoveBitBtn;
	TBitBtn *theStartResolverAutomaticMovesBitBtn;
	TBitBtn *theStopResolverAutomaticMovesBitBtn;
	TImage *thePlayIndicatorImage;
	void __fastcall FormCreate(TObject *Sender);

	void __fastcall theVRMosaicPanelResize(TObject *Sender);
	void __fastcall theCloseFormBtnClick(TObject *Sender);
	void __fastcall theShuffleTableBtnClick(TObject *Sender);
	void __fastcall theAboutBtnClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall theMosaicContainerPaneResize(TObject *Sender);
	void __fastcall theNewTableBtnClick(TObject *Sender);
	void __fastcall myApplicationEventsDeactivate(TObject *Sender);
	void __fastcall myApplicationEventsActivate(TObject *Sender);
	void __fastcall theCloseApplicMenuItemClick(TObject *Sender);
	void __fastcall theAboutThisApplicMenuItemClick(TObject *Sender);
	void __fastcall theSelectMosaicFontMenuItemClick(TObject *Sender);
	void __fastcall theSelectMosaicTabFontBitBtnClick(TObject *Sender);
	void __fastcall theShowWinCardMenuItemClick(TObject *Sender);
	void __fastcall theSetDefaultVisualStyleMenuItemClick(TObject *Sender);
	void __fastcall theOpenVisualStyleFileMenuItemClick(TObject *Sender);
	void __fastcall theResolveMosaicBitBtnClick(TObject *Sender);
	void __fastcall theStopResolverBitBtnClick(TObject *Sender);
	void __fastcall thePerformResolverSingleMoveBitBtnClick(TObject *Sender);
	void __fastcall theStartResolverAutomaticMovesBitBtnClick(TObject *Sender);
	void __fastcall theStopResolverAutomaticMovesBitBtnClick(TObject *Sender);
private:	// User declarations

	private: String theApplicVisualStyleThemeFileName;

	public: void __fastcall SetApplicVisualStyleThemeFileName (const String aFileName);

	public: __property String ApplicVisualStyleThemeFileName = {
		read = theApplicVisualStyleThemeFileName,
		write = SetApplicVisualStyleThemeFileName
	};

	public: void __fastcall OpenVisualStyleThemeFromFile();

	// the matrix

	private: TVRMosaicMatrix * mosaicMatrix;

	public: TVRMosaicMatrix * __fastcall GetMosaicMatrix();
	public: void __fastcall SetMosaicMatrix (TVRMosaicMatrix * aMatrix);

	private: TObjectList * mosaicButtons;

	// just shuffled indicator

	private: bool wasShuffled;

	// resolver progress form

	private: TVRMosaicResolverProgressForm * theResolverProgressForm;

	// methods

	public: void DoShowWinCard();

	private: void DestroyTabButtons();
	private: void __fastcall OnTabButtonClicked (TObject * sender);
	private: void CreateTabButtons();
	private: void ResizeTabButtons();
	private: void PrintTabButtons();

	public: void PrintMatrix (TVRMosaicMatrix * aMatrix);


	public: void __fastcall ResolveMosaic();

	public: void __fastcall TerminateMosaicResolverThread();

	public: void __fastcall OnResolverThreadTerminated (TObject * sender);

	public: void __fastcall SetupResolverThreadControls();

	public: void __fastcall ShowResolverProgressForm();
	public: void __fastcall HideResolverProgressForm();

	public: void __fastcall PrintResolverFeedback (
		int aGeneratedMovesCount,
		int aAnalyzedMovesCount
	);

	public: void __fastcall SolutionFound();

	public: void __fastcall SolutionDone();


	public: bool __fastcall IsWantResolverUpdates();

	public: int __fastcall GetResolverUpdateMovesCount();


	public: int __fastcall GetResolverMovesDelay();


	private: bool theIsResolverAutomaticMoves;

	private: bool theIsResolverAutomaticMoveStep;

	public: void __fastcall UpdatePlayIndicatorControls();

	public: bool __fastcall IsResolverAutomaticMoves();
	public: void __fastcall SetResolverAutomaticMoves (bool aValue);

	public: bool __fastcall IsResolverAutomaticMoveStep();
	public: void __fastcall SetResolverAutomaticMoveStep (bool aValue);


	//void __fastcall DoVRMosaicSizeChange(int aNewRCSize);
	public: void __fastcall DoVRMosaicTableSizeChange (int aNewColSize, int aNewRowSize);

	public: void __fastcall DoShuffleVRMosaicTable();


	private: void __fastcall AdjustVRMosaicPanelIntoContainer();

	//void __fastcall theTabRCSizeTextEnter();

	private: void __fastcall NewVRMosaicOnTableSizeChange();

   //theInitFName;
	public: AnsiString GetInitFName();

	private: void LoadInitParams();
	private: void StoreInitParams();

	public: void __fastcall DoShowTheAboutThisApplicDialog();

	public: void __fastcall DoSelectMosaicFont();


	private: TThread * theResolverThread;


public:		// User declarations
	__fastcall TVRMosaicForm(TComponent* Owner);
	//__fastcall virtual ~TVRMosaicForm(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TVRMosaicForm *VRMosaicForm;
//---------------------------------------------------------------------------
#endif
