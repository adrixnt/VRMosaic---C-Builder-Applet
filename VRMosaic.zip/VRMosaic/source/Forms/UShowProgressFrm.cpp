//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UShowProgressFrm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TVRMosaicResolverProgressForm *VRMosaicResolverProgressForm;
//---------------------------------------------------------------------------
__fastcall TVRMosaicResolverProgressForm::TVRMosaicResolverProgressForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TVRMosaicResolverProgressForm::FormClose(TObject *Sender, TCloseAction &Action)
{
	Action = caNone;
}
//---------------------------------------------------------------------------

	void __fastcall TVRMosaicResolverProgressForm::PrintResolverFeedback (
		int aGeneratedMovesCount,
		int aAnalyzedMovesCount
	) {
		this->theGeneratedMovesStaticText->Caption = IntToStr (aGeneratedMovesCount);
		this->theAnalyzedMovesCountStaticText->Caption = IntToStr (aAnalyzedMovesCount);
	}
