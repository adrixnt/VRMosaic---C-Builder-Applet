//---------------------------------------------------------------------------
#include <vcl.h>
#include <inifiles.hpp>
#include <mmsystem.h>

#include <dos.h>

#include <UVRAxStyleManagerHelper.hpp>

#pragma hdrstop

#include "UMainFrm.h"

#include "UAbout.h"
#include "UWinCard.h"

#include <UVRMosaicResolver.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TVRMosaicForm *VRMosaicForm;
//---------------------------------------------------------------------------
__fastcall TVRMosaicForm::TVRMosaicForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

//__fastcall TVRMosaicForm::~TVRMosaicForm(void) {}
//---------------------------------------------------------------------------

	void DoSleep (unsigned long milliSeconds)
	{
		unsigned long startTime = GetTickCount();
		while (true) {
			unsigned long currentTime = GetTickCount();
			if ((currentTime - startTime) > milliSeconds)
				break;
			{ // WaitMessage();
				MSG fake;
				PeekMessage(&fake, HWND(0), 0, UINT(-1), PM_NOREMOVE);
			}
		}
	}

	void __fastcall TVRMosaicForm::SetApplicVisualStyleThemeFileName (const String aFileName)
	{
		try {
			// always set property
			this->theApplicVisualStyleThemeFileName = aFileName;

			if (TStyleManager::ActiveStyle != TStyleManager::SystemStyle) {

				String aOldStyleName = TStyleManager::ActiveStyle->Name;

				if (aOldStyleName != "")
					//TStyleManager::RemoveStyle (aOldStyleName);
               ;
				//end if
			}

			if (aFileName != "") {
				// load style from file
				TStyleManager::TStyleServicesHandle aSSHandle = TStyleManager::LoadFromFile (aFileName);
				// set style by handle
				TStyleManager::SetStyle (aSSHandle);
				// done!
			}
			else
				// empty file name
				TStyleManager::SetStyle (TStyleManager::SystemStyle->Name);
			//end if
		}
		catch (Exception & aExcept) {
			Application->ShowException (&aExcept);
		}
		catch (...) {
         ShowMessage ("internal error");
		}
	}

	void __fastcall TVRMosaicForm::OpenVisualStyleThemeFromFile()
	{
		String aFileName = "";
		this->theVisualStyleThemeFileOpenDialog->FileName = aFileName;
		if ( this->theVisualStyleThemeFileOpenDialog->Execute() ) {
			aFileName = this->theVisualStyleThemeFileOpenDialog->FileName;
			this->ApplicVisualStyleThemeFileName = aFileName;
		 // show
			//ShowMessage (this->ApplicVisualStyleThemeFileName);
		}
	}

//========================================================================================

	TVRMosaicMatrix * __fastcall TVRMosaicForm::GetMosaicMatrix()
	{
		return this->mosaicMatrix;
	}

	void __fastcall TVRMosaicForm::SetMosaicMatrix (TVRMosaicMatrix * aMatrix)
	{
		this->mosaicMatrix = aMatrix;
	}

//========================================================================================

void TVRMosaicForm::DoShowWinCard()
{
	TYoureTheBestCard * youWinCard = new TYoureTheBestCard (this);
	DoSleep(400L);
	sndPlaySound (L"JustDone.wav", SND_ASYNC | SND_NODEFAULT);
	DoSleep(1000L);
	if (youWinCard) {
		youWinCard->ShowModal();
		youWinCard->Release();
		delete youWinCard;
	}
	else ShowMessage("Ok! Very Good!!");
}

void TVRMosaicForm::DestroyTabButtons()
{
	if (!this->mosaicButtons) return;
	//int i = 0; int cnt = this->mosaicButtons->Count;
	while (this->mosaicButtons->Count > 0) {
		TObject * o;
		o = (TObject *) this->mosaicButtons->Items[0];
		delete o;
		this->mosaicButtons->Delete(0);
	}
}

void __fastcall TVRMosaicForm::OnTabButtonClicked (TObject * sender)
{
	if (!this->mosaicButtons) return;
	TButton * btn = (TButton *) sender;
	// find clicked button index
	int index = this->mosaicButtons->IndexOf(btn);
	if (index < 0) return;
	// find the clicked (row,col)
	int clickrow, clickcol;
	this->mosaicMatrix->RCPosFromIndex(clickrow, clickcol, index);
	// try user move
	if ( this->mosaicMatrix->TrySlidingCell (clickrow, clickcol) )
	{
		// update on-screen table
		this->PrintTabButtons();
		// give sound feed-back
		sndPlaySound(L"Tak.wav", SND_ASYNC | SND_NODEFAULT);
	}
	if (this->mosaicMatrix->IsMosaicDone())
	{
		this->Update();
		if (this->wasShuffled) {
			this->wasShuffled = false;
			// Show Win Card ...
			this->DoShowWinCard();
			/*/
			TYoureTheBestCard * youWinCard = new TYoureTheBestCard (this);
			DoSleep(400L);
			sndPlaySound ("JustDone.wav", SND_ASYNC | SND_NODEFAULT);
			DoSleep(1000L);
			if (youWinCard) {
				youWinCard->ShowModal();
				delete youWinCard;
			}
			else ShowMessage("Ok! Very Good!!");
			/*/
			// end
		}
	}
}

void TVRMosaicForm::CreateTabButtons()
{
	if (!this->mosaicButtons) return;
	this->DestroyTabButtons();
	// our private matrix tell us the count
	int cnt = this->mosaicMatrix->Count();
	while (cnt > 0) {
		TButton * btn;
		btn = new TButton (this);
		// configure this button
		btn->Parent = this->theVRMosaicPanel;
		btn->Visible = false;
		btn->Caption = "";
		btn->OnClick = this->OnTabButtonClicked;
		btn->Show();
		// add the button
		this->mosaicButtons->Add (btn);
		// next one
		--cnt;
	}
}

void TVRMosaicForm::ResizeTabButtons()
{
	if (!this->mosaicButtons) return;
	// the button size is equal for all
	int aColSize = this->mosaicMatrix->ColSize();
	int aRowSize = this->mosaicMatrix->RowSize();
	int btnw = this->theVRMosaicPanel->Width / aColSize; //RCSize();
	int btnh = this->theVRMosaicPanel->Height / aRowSize; //RCSize();
	/*/
	int remw = this->theVRMosaicPanel->Width % this->mosaicMatrix.RCSize();
	int remh = this->theVRMosaicPanel->Height % this->mosaicMatrix.RCSize();
	/*/
	int r = 0;
	while (r < this->mosaicMatrix->RowSize())
	{
		int c = 0;
		while (c < this->mosaicMatrix->ColSize())
		{
			int aindex = this->mosaicMatrix->IndexFromRCPos (r, c);
			TButton * btn = 0;
			if (aindex < this->mosaicButtons->Count)
				btn = (TButton *) this->mosaicButtons->Items [aindex];
			if (btn) {
				// set x/y size : width / height
				btn->Width = btnw;
				btn->Height = btnh;
				// set x/y pos : left / top
				btn->Left = btnw * c;
				btn->Top = btnh * r;
				/*/
				if (c == (this->mosaicMatrix.RCSize() - 1))
					btn->Width += remw;
				if (r == (this->mosaicMatrix.RCSize() - 1))
					btn->Height += remh;
				/*/
				//btn->Font->Size = btn->Height - 4;
				btn->Font->Height = btn->Height * 55 / 100;
			}
			++c;
		}//loop
		++r;
	}//loop
}

void TVRMosaicForm::PrintTabButtons()
{
	if (!this->mosaicButtons) return;
	int i = 0; int cnt = this->mosaicMatrix->Count();
	int nextValue = 1;
	bool alreadyHilited = false;
	bool alreadySet = false;
	while (i < cnt)
	{
		TButton * btn = 0;
		if (i < this->mosaicButtons->Count)
			btn = (TButton *) this->mosaicButtons->Items[i];
		if (btn) {
			int cellvalue = this->mosaicMatrix->CellByIndex (i);
         btn->Caption = ""; // to be safe
			btn->Caption = IntToStr ( cellvalue );
			//btn->Font->Name = "Verdana";
			//btn->Font->Size = 20 - this->mosaicMatrix->RowSize(); //RCSize();
			//btn->Font->Height = btn->Height - 10;

			// hide it if it is the free cell
			btn->Visible = (cellvalue != 0);

			// next value hiliting
			if (cellvalue != (i + 1)) if (!alreadyHilited)
			{
				if (!alreadySet) {
					nextValue = (i + 1);
					alreadySet = true;
				}
				if (alreadySet) if (cellvalue == nextValue) {
					// hilite by setting the focus on it
					try {
						//if ( (btn->Visible) && (btn->Enabled) )
							btn->SetFocus();
						//end if
					} catch (...) { /* eat any except */ }
					//btn->Font->Size += 4;
					//btn->Caption = "[" + btn->Caption + "]";
					alreadyHilited = true;
				}
			}
		}
		++i;
	}//loop
}

//-----------------------------------------------------------------------------

	void TVRMosaicForm::PrintMatrix (TVRMosaicMatrix * aMatrix)
	{
		this->mosaicMatrix->CopyDataFrom (aMatrix);
		//TThread::Sleep (300);
		this->PrintTabButtons();
		//this->Repaint();
	}

//========================================================================================

	void __fastcall TVRMosaicForm::OnResolverThreadTerminated (TObject * sender)
	{
		this->theResolverThread = NULL;
		this->SetupResolverThreadControls();
	}

	void __fastcall TVRMosaicForm::TerminateMosaicResolverThread()
	{
		if (this->theResolverThread != NULL)
			this->theResolverThread->Terminate();
		//end if
	}

	void __fastcall TVRMosaicForm::ResolveMosaic()
	{
		if (this->theResolverThread == NULL) {

			TVRMosaicResolver * aResolverThread = new TVRMosaicResolver();
			aResolverThread->FreeOnTerminate = true;
			aResolverThread->theMosaicForm = this;
			aResolverThread->theResolverProgressForm = this->theResolverProgressForm;
			aResolverThread->OnTerminate = this->OnResolverThreadTerminated;

			this->theResolverThread = aResolverThread;

			this->SetupResolverThreadControls();

			this->theResolverThread->Start();
		}
	}

	void __fastcall TVRMosaicForm::SetupResolverThreadControls()
	{
		this->theResolverThreadRunningIndicatorImage->Visible = ( this->theResolverThread != NULL );
	}


//========================================================================================

	void __fastcall TVRMosaicForm::ShowResolverProgressForm()
	{
		this->theResolverProgressForm->Visible = true;
	}

	void __fastcall TVRMosaicForm::HideResolverProgressForm()
	{
		this->theResolverProgressForm->Visible = false;
	}

	void __fastcall TVRMosaicForm::PrintResolverFeedback (
		int aGeneratedMovesCount,
		int aAnalyzedMovesCount
	) {
		this->theResolverProgressForm->PrintResolverFeedback (
			aGeneratedMovesCount,
			aAnalyzedMovesCount
		);
	}

	void __fastcall TVRMosaicForm::SolutionFound()
	{
		// also play sound
		sndPlaySound (L"JustDone.wav", SND_ASYNC | SND_NODEFAULT);
		ShowMessage ("Solution Found !!");
	}

	void __fastcall TVRMosaicForm::SolutionDone()
	{
		// also play sound
		sndPlaySound (L"JustDone.wav", SND_ASYNC | SND_NODEFAULT);
		ShowMessage ("DONE");
	}



//========================================================================================

	bool __fastcall TVRMosaicForm::IsWantResolverUpdates()
	{
		return this->theWantResolverUpdatesCheckBox->Checked;
	}

	int __fastcall TVRMosaicForm::GetResolverUpdateMovesCount()
	{
		return this->theUpdateMovesCountSpinEdit->Value;
	}


	int __fastcall TVRMosaicForm::GetResolverMovesDelay()
	{
		return this->theResolverMovesDelaySpinEdit->Value;
	}


    // update play controls

	void __fastcall TVRMosaicForm::UpdatePlayIndicatorControls()
	{
		this->thePlayIndicatorImage->Visible =
			( this->IsResolverAutomaticMoveStep() ) ||
			( this->IsResolverAutomaticMoves() )
		;
	}


	bool __fastcall TVRMosaicForm::IsResolverAutomaticMoves()
	{
		return this->theIsResolverAutomaticMoves;
	}

	void __fastcall TVRMosaicForm::SetResolverAutomaticMoves (bool aValue)
	{
		this->theIsResolverAutomaticMoves = aValue;
		this->UpdatePlayIndicatorControls();
	}


	bool __fastcall TVRMosaicForm::IsResolverAutomaticMoveStep()
	{
		return this->theIsResolverAutomaticMoveStep;
	}

	void __fastcall TVRMosaicForm::SetResolverAutomaticMoveStep (bool aValue)
	{
		this->theIsResolverAutomaticMoveStep = aValue;
		this->UpdatePlayIndicatorControls();
	}


//-----------------------------------------------------------------------------

AnsiString TVRMosaicForm::GetInitFName()
{
	return ExtractFilePath(ParamStr(0)) + "vrmosaic.ini";
}

void TVRMosaicForm::LoadInitParams()
{
	TIniFile * initfile = new TIniFile(this->GetInitFName());
	try {
		// read visual style file name
		this->ApplicVisualStyleThemeFileName = initfile->ReadString (
			"general.applic.settings",
			"ApplicVisualStyleThemeFileName",
			this->ApplicVisualStyleThemeFileName
		);
		// read form size and position
		int formleft = initfile->ReadInteger("general.form.options", "formx", -1);
		int formtop = initfile->ReadInteger("general.form.options", "formy", -1);
		int formwidth = initfile->ReadInteger("general.form.options", "formw", -1);
		int formheight = initfile->ReadInteger("general.form.options", "formh", -1);
		if (formleft > 0) this->Left = formleft;
		if (formtop > 0) this->Top = formtop;
		if (formwidth > 0) this->Width = formwidth;
		if (formheight > 0) this->Height = formheight;
		// read the default mosaic tab size
		//int rcsize = initfile->ReadInteger("general.mosaic.settings", "tabsize", 4);
		//if (rcsize < 3) rcsize = 3; if (rcsize > 10) rcsize = 10;
		int csize = initfile->ReadInteger("general.mosaic.settings", "tabcolsize", 4);
		int rsize = initfile->ReadInteger("general.mosaic.settings", "tabrowsize", 4);
		if (csize <= 1) csize = 2;
		if (rsize <= 1) rsize = 2;
		this->mosaicMatrix->NewSize (csize, rsize);
		// read the mosaic font
		this->theVRMosaicPanel->Font->Name =
			initfile->ReadString (
				"mosaic.format", "font", this->theVRMosaicPanel->Font->Name
			);
		// done!
	} __finally {
		delete initfile;
	}
}

void TVRMosaicForm::StoreInitParams()
{
	TIniFile * initfile = new TIniFile(this->GetInitFName());
	try {
		// write visual style file name
		//ShowMessage ("Saving: " + this->ApplicVisualStyleThemeFileName);
		initfile->WriteString (
			"general.applic.settings",
			"ApplicVisualStyleThemeFileName",
			this->ApplicVisualStyleThemeFileName
		);
		// write the default mosaic tab size
		//initfile->WriteInteger
			//("general.mosaic.settings", "tabsize", this->mosaicMatrix.RCSize());
		initfile->WriteInteger
			("general.mosaic.settings", "tabcolsize", this->mosaicMatrix->ColSize());
		initfile->WriteInteger
			("general.mosaic.settings", "tabrowsize", this->mosaicMatrix->RowSize());
		// write form size and position
		initfile->WriteInteger("general.form.options", "formx", this->Left);
		initfile->WriteInteger("general.form.options", "formy", this->Top);
		initfile->WriteInteger("general.form.options", "formw", this->Width);
		initfile->WriteInteger("general.form.options", "formh", this->Height);
		// write the mosaic font
		initfile->WriteString (
			"mosaic.format", "font", this->theVRMosaicPanel->Font->Name
		);
	// done!
	} __finally {
		delete initfile;
	}
}
//-----------------------------------------------------------------------------

void __fastcall TVRMosaicForm::FormCreate (TObject * Sender)
{
	this->theResolverProgressForm = new TVRMosaicResolverProgressForm (this);

	this->theResolverThread = NULL;

	this->SetupResolverThreadControls();

	this->SetResolverAutomaticMoves (false);
	this->SetResolverAutomaticMoveStep (false);

	this->UpdatePlayIndicatorControls();

	// create the mosaic matrix
	this->mosaicMatrix = new TVRMosaicMatrix();
	//
	this->wasShuffled = false;
	//
	// create the tab buttons list
	this->mosaicButtons = new TObjectList (false);
	//
	this->theVRMosaicPanel->Caption = "";
	//
	// create our internal matrix with a default size
	this->mosaicMatrix->NewSize (4, 4);
	//
	this->ApplicVisualStyleThemeFileName = "";
	//
	// try to load init params
	this->LoadInitParams();
	//
	// show the text for matrix rows, cols
	//this->theTabColSizeTxt->Text = IntToStr (this->mosaicMatrix->ColSize());
	this->theTabColSizeTxt->Value = this->mosaicMatrix->ColSize();
	//this->theTabRowSizeTxt->Text = IntToStr (this->mosaicMatrix->RowSize());
	this->theTabRowSizeTxt->Value = this->mosaicMatrix->RowSize();
	//
	// initial shuffle
	this->mosaicMatrix->RandomShuffle();
	this->wasShuffled = true;
	//
	// update screen
	this->CreateTabButtons();
	this->ResizeTabButtons();
	this->PrintTabButtons();
	// ok!
	sndPlaySound (L"JustDone.wav", SND_ASYNC | SND_NODEFAULT);
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::FormDestroy (TObject * Sender)
{
	if (this->theResolverThread != NULL) {
		this->theResolverThread->Terminate();
	}

	this->mosaicButtons->Clear();
	delete this->mosaicButtons;
	//
	try {
		// try to store data into ini-file
		this->StoreInitParams();
	}
	catch (...) {
		MessageBeep (0);
	}

	// clean up

	delete this->mosaicMatrix;

	delete this->theResolverProgressForm;

	//
	sndPlaySound (L"OnExit.wav", SND_NODEFAULT);
	// sleep a while
	DoSleep(800L);
}

//---------------------------------------------------------------------------

	// to show the About ... box

	void __fastcall TVRMosaicForm :: DoShowTheAboutThisApplicDialog()
	{
		TTheAboutBox * aboutBox = new TTheAboutBox(this);
		//if (!aboutBox) return;
		try {
			aboutBox->ShowModal();
		}
		__finally {
			delete aboutBox;
		}
	}

//---------------------------------------------------------------------------

	// to select the mosaic font

	void __fastcall TVRMosaicForm :: DoSelectMosaicFont()
	{
		this->theMosaicFontDialog->Font->Name = this->theVRMosaicPanel->Font->Name;
		bool ok = this->theMosaicFontDialog->Execute();
		if (!ok) return;
		this->theVRMosaicPanel->Font->Name = this->theMosaicFontDialog->Font->Name;
		// also change the font of all buttons
		{
			int aCount = this->mosaicButtons->Count;
			int aIndex = 0;
			while (aIndex < aCount) {
				TButton * btn = (TButton *) this->mosaicButtons->Items[aIndex];
				btn->Font->Name = this->theVRMosaicPanel->Font->Name;
				++ aIndex;
			}
		}
	}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theVRMosaicPanelResize(TObject *Sender)
{
	this->ResizeTabButtons();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theCloseFormBtnClick(TObject *Sender)
{
	this->Close();	
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theShuffleTableBtnClick(TObject *Sender)
{
	//this->mosaicMatrix->RandomShuffle();
	//this->wasShuffled = true;
	//this->PrintTabButtons();
	this->DoShuffleVRMosaicTable();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm :: DoShuffleVRMosaicTable()
{
	this->mosaicMatrix->RandomShuffle();
	this->wasShuffled = true;
	this->PrintTabButtons();
}

//void __fastcall TVRMosaicForm :: DoVRMosaicSizeChange (int aNewRCSize)
void __fastcall TVRMosaicForm :: DoVRMosaicTableSizeChange (int aNewColSize, int aNewRowSize)
{
	//int newRCSize = aNewRCSize;
	const int minRCSize = 2;
	const int maxRCSize = 10;
	/*/ clip value /*/
	//if (newRCSize < minRCSize)
		//newRCSize = minRCSize;
	//if (newRCSize > maxRCSize)
		//newRCSize = maxRCSize;
	// clip col size
	int newColSize = aNewColSize;
	if (newColSize < minRCSize) newColSize = minRCSize;
	if (newColSize > maxRCSize) newColSize = maxRCSize;
	// clip row size
	int newRowSize = aNewRowSize;
	if (newRowSize < minRCSize) newRowSize = minRCSize;
	if (newRowSize > maxRCSize) newRowSize = maxRCSize;

	//if (newRCSize != aNewRCSize)
		//ShowMessage(
		//"the value you entered [" + IntToStr(aNewRCSize) + "]\n"
		//"was clipped to [" + IntToStr(newRCSize) + "]"
	//);

	/*/ get old size /*/
	//int oldRCSize = this->mosaicMatrix.RCSize();
	int oldColSize = this->mosaicMatrix->ColSize();
	int oldRowSize = this->mosaicMatrix->RowSize();

	//bool haveDifferentSize = (newRCSize != oldRCSize);
	bool haveDifferentSize = (newColSize != oldColSize) || (newRowSize != oldRowSize);

	/*/ re-create our internal matrix using the new size /*/
	if (haveDifferentSize)
		// only if the size is changing
		this->mosaicMatrix->NewSize (newColSize, newRowSize);

	/*/ always shuffle it /*/
	this->mosaicMatrix->RandomShuffle();
	this->wasShuffled = true;

	/*/ update screen /*/
	if (haveDifferentSize)
	{
		this->CreateTabButtons();
		this->ResizeTabButtons();
	}
	// because the new rc-size cannot always be an exact divisor of cont-w/h
	// then adjust the mosaic panel to fit its container
	if (haveDifferentSize)
		this->AdjustVRMosaicPanelIntoContainer();

	/*/ print numbers on tab buttons /*/
	this->PrintTabButtons();
	// set the caption text
	//this->theTabRCSizeTxt->Text = IntToStr(this->mosaicMatrix.RCSize());
	//this->theTabColSizeTxt->Text = IntToStr (this->mosaicMatrix->ColSize());
	//this->theTabRowSizeTxt->Text = IntToStr (this->mosaicMatrix->RowSize());
	this->theTabColSizeTxt->Value = this->mosaicMatrix->ColSize();
	this->theTabRowSizeTxt->Value = this->mosaicMatrix->RowSize();
	// done!
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm :: NewVRMosaicOnTableSizeChange()
{
	/*/
	AnsiString aColSizeStr = this->theTabColSizeTxt->Text;
	AnsiString aRowSizeStr = this->theTabRowSizeTxt->Text;
	int newColSize = StrToInt (aColSizeStr);
	int newRowSize = StrToInt (aRowSizeStr);
	/*/
	/*/ do set the new sizes /*/
	int newColSize = this->theTabColSizeTxt->Value;
	int newRowSize = this->theTabRowSizeTxt->Value;
	this->DoVRMosaicTableSizeChange (newColSize, newRowSize);
}

/*/
void __fastcall TVRMosaicForm :: theTabRCSizeTextEnter()
{
	int newRCSize;
	try {
		newRCSize = StrToInt(this->theTabRCSizeTxt->Text);
	} catch (...) {
		// in the case it is not a valid number string
		ShowMessage(
			"Sorry, but ''" + this->theTabRCSizeTxt->Text + "'' is NOT a Valid integer value.\n"
			"Please enter it again, Sam ..."
		);
		if (this->theTabRCSizeTxt->CanFocus())
			this->theTabRCSizeTxt->SetFocus();
		return; // newRCSize = 0;
	}
	// do set the new size
	this->DoVRMosaicSizeChange(newRCSize);
}
/*/


//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theAboutBtnClick(TObject *Sender)
{
	/*/
	TTheAboutBox * aboutBox = new TTheAboutBox(this);
	if (!aboutBox) return;
	aboutBox->ShowModal();
	delete aboutBox;
	/*/
	this->DoShowTheAboutThisApplicDialog();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::AdjustVRMosaicPanelIntoContainer()
{
	//int rcsize = this->mosaicMatrix.RCSize();
	//if (!rcsize)
		//rcsize = 1;
	int acolSize = this->mosaicMatrix->ColSize();
	int arowSize = this->mosaicMatrix->ColSize();
	if (acolSize <= 0) acolSize = 1;
	if (arowSize <= 0) arowSize = 1;

	int newW = this->theMosaicContainerPane->Width;
	//(this->theMosaicContainerPane->Width / rcsize) * rcsize;
	int newH = this->theMosaicContainerPane->Height;
	//(this->theMosaicContainerPane->Height / rcsize) * rcsize;

	/*/ re-size /*/

	/*/ arbitrary margin value /*/
	if (newW > 4) newW -= 4;
	if (newH > 4) newH -= 4;

	newW -= (newW % acolSize);
	newH -= (newH % arowSize);

	this->theVRMosaicPanel->Width = newW;
	this->theVRMosaicPanel->Height = newH;

	/*/ re-position after a change in size /*/

	int newL = (this->theMosaicContainerPane->Width - this->theVRMosaicPanel->Width) / 2;
	int newT = (this->theMosaicContainerPane->Height - this->theVRMosaicPanel->Height) / 2;

	this->theVRMosaicPanel->Left = newL;
	this->theVRMosaicPanel->Top = newT;
}


void __fastcall TVRMosaicForm::theMosaicContainerPaneResize(TObject *Sender)
{
	this->AdjustVRMosaicPanelIntoContainer();
}
//---------------------------------------------------------------------------



//void __fastcall TVRMosaicForm::theTabColSizeTxtKeyUp(TObject *Sender,
		//WORD &Key, TShiftState Shift)
//{
	//if ((Shift.Contains(ssCtrl)) && (Key == WORD('S')))
	//{
		//Key = 0;
		//this->theTabRCSizeTxt->Text = InputBox("", "New Mosaic Size ...", "0"); //
		//this->theTabRCSizeTxt->OnChange(this);
	//}
//}


void __fastcall TVRMosaicForm::theNewTableBtnClick(TObject *Sender)
{
	this->NewVRMosaicOnTableSizeChange();	
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::myApplicationEventsDeactivate(
      TObject *Sender)
{
	this->AlphaBlend = true;
	//this->AlphaBlendValue = (150);
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::myApplicationEventsActivate(TObject *Sender)
{
	this->AlphaBlend = false;
	//this->AlphaBlendValue = 255;	
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theCloseApplicMenuItemClick(TObject *Sender)
{
	this->Close();	
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theAboutThisApplicMenuItemClick(TObject *Sender)
{
	this->DoShowTheAboutThisApplicDialog();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theSelectMosaicFontMenuItemClick(
      TObject *Sender)
{
	this->DoSelectMosaicFont();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theSelectMosaicTabFontBitBtnClick(TObject *Sender)
{
	this->DoSelectMosaicFont();
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theShowWinCardMenuItemClick(TObject *Sender)
{
	this->DoShowWinCard();
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theSetDefaultVisualStyleMenuItemClick(TObject *Sender)
{
	this->ApplicVisualStyleThemeFileName = "";
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theOpenVisualStyleFileMenuItemClick(TObject *Sender)
{
	this->OpenVisualStyleThemeFromFile();
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theResolveMosaicBitBtnClick(TObject *Sender)
{
   this->ResolveMosaic();
}

//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theStopResolverBitBtnClick(TObject *Sender)
{
	this->TerminateMosaicResolverThread();
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::thePerformResolverSingleMoveBitBtnClick(TObject *Sender)
{
	this->SetResolverAutomaticMoveStep ( true );
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theStartResolverAutomaticMovesBitBtnClick(TObject *Sender)
{
	this->SetResolverAutomaticMoves ( true );
}
//---------------------------------------------------------------------------

void __fastcall TVRMosaicForm::theStopResolverAutomaticMovesBitBtnClick(TObject *Sender)
{
	this->SetResolverAutomaticMoves ( false );
}
//---------------------------------------------------------------------------

