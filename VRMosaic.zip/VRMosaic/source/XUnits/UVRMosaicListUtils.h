//---------------------------------------------------------------------------

#ifndef UVRMosaicListUtilsH
#define UVRMosaicListUtilsH
//---------------------------------------------------------------------------

	#include <Classes.hpp>
	#include <SysUtils.hpp>


	// range check

	bool __fastcall IsListItemIndexValid (TList * aList, int aIndex);

	bool __fastcall IsListInsertIndexValid (TList * aList, int aIndex);


	// binary search

	int __fastcall BinSearchList (
		TList * aList,
		void * aItemToSearch,
		TListSortCompare aCompareFunc
	);


	// duplicates mode

	enum DuplicatesMode {
		doNotAllowDuplicates,
		allowDuplicates,
		ignoreDuplicates
	};

	// ordered insert

	int __fastcall InsertListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc,
		DuplicatesMode aDuplicatesMode
	);

	int __fastcall InsertUniqueListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc
	);

	int __fastcall InsertDupsListOrderedItem (
		TList * aList,
		void * aItemToInsert,
		TListSortCompare aCompareFunc
	);

#endif
