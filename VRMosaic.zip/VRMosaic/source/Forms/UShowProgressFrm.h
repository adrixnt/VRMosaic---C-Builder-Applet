//---------------------------------------------------------------------------

#ifndef UShowProgressFrmH
#define UShowProgressFrmH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Graphics.hpp>
//---------------------------------------------------------------------------
class TVRMosaicResolverProgressForm : public TForm
{
__published:	// IDE-managed Components
	TStaticText *StaticText1;
	TStaticText *StaticText2;
	TStaticText *theGeneratedMovesStaticText;
	TStaticText *theAnalyzedMovesCountStaticText;
	TImage *Image1;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
	__fastcall TVRMosaicResolverProgressForm(TComponent* Owner);


	public: void __fastcall PrintResolverFeedback (
		int aGeneratedMovesCount,
		int aAnalyzedMovesCount
	);

};
//---------------------------------------------------------------------------
extern PACKAGE TVRMosaicResolverProgressForm *VRMosaicResolverProgressForm;
//---------------------------------------------------------------------------
#endif
