
#ifndef __UVRMosaicResolverH__

#define __UVRMosaicResolverH__

//#define __exclude_unit_impl
#include <matrixm.h>

#include <UMainFrm.h>
#include <UShowProgressFrm.h>

#include <UVRMosaicResolver.h>

#include <UVRMosaicSolverNode.h>

#include <Classes.hpp>

	class TVRMosaicResolver : public TThread
	{

		public: TVRMosaicForm * theMosaicForm; // [weak]

		public: TVRMosaicResolverProgressForm * theResolverProgressForm; // [weak]

		public: static void __fastcall Resolve (
			TVRMosaicResolver * aThread,
			TVRMosaicForm * aMosaicForm,
			TVRMosaicMatrix * aStartingMatrix
		);

		// constructor
		public: __fastcall TVRMosaicResolver();

		public: virtual void __fastcall Execute();

		public: void __fastcall ShowResolverProgressForm();
		public: void __fastcall HideResolverProgressForm();

		public: void __fastcall PrintResolverFeedback (
			int aGeneratedMovesCount,
			int aAnalyzedMovesCount
		);

		public: void __fastcall SolutionFound();

		public: void __fastcall SolutionDone();

		public: void __fastcall ShowMovesCount (int aMovesCount);

		public: void __fastcall PrintMatrix (TVRMosaicMatrix * aMatrix);

		public: void __fastcall WaitForMoveAllowed();

	};


#endif