//---------------------------------------------------------------------------
#ifndef UAboutH
#define UAboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TTheAboutBox : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TImage *Image1;
	TStaticText *StaticText1;
	TPanel *Panel2;
	TStaticText *StaticText2;
	TBitBtn *theCloseBitBtn;
	TStaticText *StaticText3;
	TStaticText *StaticText4;
	TImage *Image2;
	TStaticText *StaticText5;
	TStaticText *StaticText6;
	TStaticText *StaticText7;
	TStaticText *StaticText8;
	void __fastcall theCloseBitBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TTheAboutBox(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTheAboutBox *TheAboutBox;
//---------------------------------------------------------------------------
#endif
