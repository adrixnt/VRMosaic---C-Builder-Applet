//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UWinCard.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TYoureTheBestCard *YoureTheBestCard;
//---------------------------------------------------------------------------
__fastcall TYoureTheBestCard::TYoureTheBestCard(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TYoureTheBestCard::TheCloseCardBtnClick(TObject *Sender)
{
	this->Close();	
}
//---------------------------------------------------------------------------
void __fastcall TYoureTheBestCard::theBigWinnerImageClick(TObject *Sender)
{
	this->Close();	
}
//---------------------------------------------------------------------------

