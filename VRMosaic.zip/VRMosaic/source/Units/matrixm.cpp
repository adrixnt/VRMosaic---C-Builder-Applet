// C++ Unit


//--------------------------------------------------------------------------------------------------

#include <stdlib.h>

#include <matrixm.h>


      // constructor

		TVRMosaicMatrix :: TVRMosaicMatrix() :
			fRowSize (0),
			fColSize (0),
			xdata (NULL)
		{}


// -- -- --

	void TVRMosaicMatrix :: LocateCellRCPos (int & arow, int & acol, int cellvalue) const
	{
		int cnt = this->Count();
		int i = 0;
		for (; i < cnt; ++i)
			if (this->xdata[i] == cellvalue)
				break;
		this->RCPosFromIndex (arow, acol, i);
	}

// -- -- --

	TVRMosaicMatrix :: TCellMoveDir
		TVRMosaicMatrix :: FindCellMoveDir (int & movesize, int arow, int acol) const
	{
		movesize = 0;
		int freer, freec;
		// locate the free cell (r,c) pos
		this->LocateFreeCellRCPos (freer, freec);
		if ((freer == arow) && (freec == acol))
			// cannot move the free-cell itself
			return cannotMove;
		if (freer == arow)
			// can move on the same row
			if (freec < acol) {
				movesize = acol - freec;
				return canMoveLeft;
			}
			else {
				movesize = freec - acol;
				return canMoveRight;
			}
		else
		if (freec == acol)
			// can be moved on the same col
			if (freer < arow) {
				movesize = arow - freer;
				return (canMoveUp);
			}
			else {
				movesize = freer - arow;
				return (canMoveDown);
			}
		else
			return cannotMove; // cannot move
		//end if
	}

	bool TVRMosaicMatrix :: TrySlidingCell (int arow, int acol) const
	{
		int cnt = 0;
		TCellMoveDir dir = this->FindCellMoveDir (cnt, arow, acol);
		// check moves
		if (dir == canMoveLeft)
			// move left <-- COL
			for (int c = acol - cnt + 1; c <= acol; ++c)
				this->SwapCell (arow, c, arow, c - 1);
		else
		if (dir == canMoveRight)
			// move right COL -->
			for (int c = acol + cnt - 1; c >= acol; --c)
				this->SwapCell (arow, c, arow, c + 1);
		else
		if (dir == canMoveUp)
			// move up <-- ROW
			for (int r = arow - cnt + 1; r <= arow; ++r)
				this->SwapCell (r, acol, r - 1, acol);
		else
		if (dir == canMoveDown)
			// move down ROW -->
			for (int r = arow + cnt - 1; r >= arow; --r)
				this->SwapCell (r, acol, r + 1, acol);
		else
			// cannot move
			return false;
		return true;
	}

	// can we slide a cell ?

	bool TVRMosaicMatrix :: CanSlideCellUp() const
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		if ( (arow >= 0) && (arow < this->RowSize() - 1) )
			return true;
		else
			return false;
	}

	bool TVRMosaicMatrix :: CanSlideCellDown() const
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		if ( (arow >= 1) && (arow < this->RowSize()) )
			return true;
		else
			return false;
	}

	bool TVRMosaicMatrix :: CanSlideCellLeft() const
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		if ( (acol >= 0) && (acol < this->ColSize() - 1) )
			return true;
		else
			return false;
	}

	bool TVRMosaicMatrix :: CanSlideCellRight() const
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		if ( (acol >= 1) && (acol < this->ColSize()) )
			return true;
		else
			return false;
	}


	// slide a cell

	void TVRMosaicMatrix :: SlideCellUp()
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		// cell to slide row
		arow = arow + 1;
		this->TrySlidingCell (arow, acol);
	}

	void TVRMosaicMatrix :: SlideCellDown()
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		// cell to slide row
		arow = arow - 1;
		this->TrySlidingCell (arow, acol);
	}

	void TVRMosaicMatrix :: SlideCellLeft()
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		// cell to slide col
		acol = acol + 1;
		this->TrySlidingCell (arow, acol);
	}

	void TVRMosaicMatrix :: SlideCellRight()
	{
		int arow = -1;
		int acol = -1;
		this->LocateFreeCellRCPos (arow, acol);
		// cell to slide col
		acol = acol - 1;
		this->TrySlidingCell (arow, acol);
	}


	int TVRMosaicMatrix :: ComputeManhattan() const
	{
      int aManhattanCount = 0;
		int aSize = this->Count();
		for (int i = 0; i < aSize; ++i) {
			if (this->xdata [i] != 0)
				if (this->xdata [i] != (i + 1))
   	         ++ aManhattanCount;
		}
      return aManhattanCount;
	}


// -- -- --

	void TVRMosaicMatrix :: ZeroInit() const
	{
		if (!this->AnyData()) return;
		int cnt = this->Count();
		for (int i = 0; i < cnt; ++i)
			this->xdata[i] = 0;
	}

	void TVRMosaicMatrix :: InitFill() const
	{
		if (!this->AnyData()) return;
		int cnt = this->Count();
		if (cnt > 1)
			for (int i = 0; i < cnt - 1; ++i)
				this->xdata[i] = i + 1;
		this->xdata[cnt - 1] = 0; // set the free cell
	}

	bool TVRMosaicMatrix :: IsMosaicDone() const
	{
		if (!this->AnyData()) return false;
		int cnt = this->Count();
		if (cnt > 1)
			for (int i = 1; i < cnt - 1; ++i)
				if ((this->xdata[i - 1] != 0) && (this->xdata[i] != 0))
					// not a free cell
					if (this->xdata[i - 1] < this->xdata[i])
						continue;
					else
						return false; // values are not sorted
				else
					return false; // the free cell was encountered
		// check if the free cell is the last one
		if (this->xdata[cnt - 1] != 0)
			return false;
		return true;
	}

		/*/
		while (cnt > 0)
		cbegin
			unsigned char
				randrowa = random(self.RCSize()),
				randcola = random(self.RCSize()),
				randrowb = random(self.RCSize()),
				randcolb = random(self.RCSize())
			;
			self.SwapCell(randrowa, randcola, randrowb, randcolb);
			--cnt;
		endc
		/*/

	void TVRMosaicMatrix :: RandomShuffle() const
	{
		randomize();
		int cnt = 1024;
		while (cnt > 0)
		{
			int shrow, shcol;
			this->LocateFreeCellRCPos (shrow, shcol);
			TCellMoveDir randomdir = (TCellMoveDir) (random(5) - 2);
			//int randomspc = random(self.RCSize() + 1);
			int randomspcCol = random(this->ColSize() + 1);
			int randomspcRow = random(this->RowSize() + 1);
			switch (randomdir) {
			case canMoveLeft:
				shcol += randomspcCol;
				break;
			case canMoveRight:
				shcol -= randomspcCol;
				break;
			case canMoveUp:
				shrow += randomspcRow;
				break;
			case canMoveDown:
				shrow -= randomspcRow;
				break;
			}
			shcol = this->ConstrainColPos (shcol);
			shrow = this->ConstrainRowPos (shrow);
			// try to slide at (shrow, shcol)
			this->TrySlidingCell (shrow, shcol);
			// next
			--cnt;
		}
	}

// -- -- --

	void TVRMosaicMatrix :: CopyDataFrom (TVRMosaicMatrix * that)
	{
		// should we check row / col sizes here ?
		int aSize = that->Count();
		for (int i = 0; i < aSize; i++) {
			this->xdata [i] = that->xdata [i];
		}
	}

	void TVRMosaicMatrix :: CopyFrom (TVRMosaicMatrix * that)
	{
		this->NewSize (that->ColSize(), that->RowSize());
		this->CopyDataFrom (that);
	}


	bool TVRMosaicMatrix :: EqualsTo (TVRMosaicMatrix * that) const
	{
		// should we check row / col sizes here ?
		int aSize = that->Count();
		for (int i = 0; i < aSize; i++) {
			if ( this->xdata [i] != that->xdata [i] )
				return false;
		}
		return true;
	}


	void TVRMosaicMatrix :: FreeAnyData()
	{
		if (this->xdata != NULL)
			//delete [] this->xdata;
			free (this->xdata);
		//end if
		this->xdata = NULL;
		//self.rcsize = 0;
		this->fColSize = 0;
		this->fRowSize = 0;
	}

	TVRMosaicMatrix :: ~ TVRMosaicMatrix()
	{
		this->FreeAnyData();
	}

	bool TVRMosaicMatrix :: NewSize (int anewcolsize, int anewrowsize)
	{
		int asize = anewcolsize * anewrowsize;
		int * aptr = 0;
		if (asize > 0) {
			aptr = (int *) malloc (asize * sizeof(int));
			//aptr = new int [asize];
			//if (!aptr) return false; // on failure: exit without any change
		}
		this->FreeAnyData();
		//
		this->xdata = aptr;
		//self.rcsize = newrcsize;
		this->fColSize = anewcolsize;
		this->fRowSize = anewrowsize;
		//
		this->ZeroInit();
		this->InitFill();
		//
		return true;
	}


	// clone

	TVRMosaicMatrix * TVRMosaicMatrix :: Clone() const
	{
		TVRMosaicMatrix * that = new TVRMosaicMatrix();
		try {
			that->NewSize (this->ColSize(), this->RowSize());
			// copy data from this to that
			int aSize = this->Count();
			for (int i = 0; i < aSize; i++) {
            // copy data from this to that
				that->xdata [i] = this->xdata [i];
			}
			// done
		} catch (...) {
			delete that;
			throw;
		}
      return that;
	}



//  t h a t ' s   a l l   f o l k s . . .