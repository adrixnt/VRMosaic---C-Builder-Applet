
#ifndef __VRMosaicMatrix_H__

#define __VRMosaicMatrix_H__


//#include <stdio.h>
//#include <conio.h>
//#include <string.h>

//#include <verbose.inc>
//#include <inhcls.inc>

//#define self (*this)

#include <stddef.h>


	class TVRMosaicMatrix
	{
	
	private:
		//unsigned char rcsize;
		int fRowSize;
		int fColSize;
		//unsigned char * xdata;
		int * xdata;
	
	public:
		// move direction
		// -- (-1) : up, (+1) : down
		// -- (-2) : left, (+2) : right
		// -- (0) : cannot move
	
		enum TCellMoveDir {
			canMoveLeft = -2,
			canMoveUp = -1,
			cannotMove = 0,
			canMoveDown = 1,
			canMoveRight = 2
		};
	
		// -- -- --
	
		// basic query
	
		bool AnyData() const { return this->xdata != NULL; }
	
		//unsigned char RCSize() const { return self.rcsize; }
	
		int RowSize() const { return this->fRowSize; }
		int ColSize() const { return this->fColSize; }
	
		//unsigned char Count() const  { return self.rcsize * self.rcsize; }
		int Count() const { return this->ColSize() * this->RowSize(); }
	
		// utils
	
		//unsigned char ConstrainRCPos(unsigned char aRCPos) const
		//cbegin
			//if (aRCPos < 0) return (0);
			//if (aRCPos >= self.RCSize()) return self.RCSize() - 1;
			//return aRCPos;
		//endc
	
		int ConstrainColPos (int aColPos) const
		{
			if (aColPos < 0) return (0);
			if (aColPos >= this->ColSize()) return this->ColSize() - 1;
			return aColPos;
		}
	
		int ConstrainRowPos (int aRowPos) const
		{
			if (aRowPos < 0) return (0);
			if (aRowPos >= this->RowSize()) return this->RowSize() - 1;
			return aRowPos;
		}
	
		// (row, col) from index
	
		void RCPosFromIndex (int & arow, int & acol, int aindex) const
		{
			arow = aindex / this->ColSize();
			acol = aindex % this->ColSize();
			//return aindex;
		}
	
		// index from (row, col)
	
		int IndexFromRCPos (int arow, int acol) const
		{
			return acol + (arow * this->ColSize());
		}
	
		// get cell value
	
		int Cell (int arow, int acol) const
		{
			int retval = 0;
			retval = this->xdata [ this->IndexFromRCPos (arow, acol) ];
			return retval;
		}
	
		int CellByIndex (int aindex) const
		{
			return this->xdata [aindex];
		}
	
		// set cell value
	
		int Cell (int arow, int acol, int newvalue) const
		{
			int retval = this->Cell (arow, acol);
			this->xdata [ this->IndexFromRCPos (arow, acol) ] = newvalue;
			return retval;
		}

		// swap cell values

		void SwapCell (int rowa, int cola, int rowb, int colb) const
		{
			int aval = this->Cell (rowa, cola);
			int bval = this->Cell (rowb, colb);
			this->Cell (rowa, cola, bval);
			this->Cell(rowb, colb, aval);
		}

		// cell data

		int Data (int aIndex) { return this->xdata [aIndex]; }

		void Data (int aIndex, int aValue) { this->xdata [aIndex] = aValue; }

		// locating cells by value
	
		void LocateCellRCPos (int & arow, int & acol, int cellvalue) const;
			// external
	
		void LocateFreeCellRCPos (int & arow, int & acol) const
		{
			this->LocateCellRCPos (arow, acol, 0);
		}
	
		// moving mosaic cells
	
		TCellMoveDir FindCellMoveDir (int & movesize, int arow, int acol) const;
			// external
	
		bool TrySlidingCell (int arow, int acol) const;
			// external
	
		// can slide cell ?
	
		bool CanSlideCellUp() const;
		bool CanSlideCellDown() const;
		bool CanSlideCellLeft() const;
		bool CanSlideCellRight() const;
	
		// slide a cell
	
		void SlideCellUp();
		void SlideCellDown();
		void SlideCellLeft();
		void SlideCellRight();
	
	   // compute Manhattan
	
		int ComputeManhattan() const;
	
		// init / done
	
		void ZeroInit() const; // external
		void InitFill() const; // external
		void RandomShuffle() const; // external
	
		bool IsMosaicDone() const; // external

		// init

		//TVRMosaicSqrMatrix() : rcsize(0), xdata(0) {}
		TVRMosaicMatrix(); /*/ :
			fRowSize (0),
			fColSize (0),
			xdata (NULL)
		{}
			// external
		/*/
	
		void CopyDataFrom (TVRMosaicMatrix * that);

		void CopyFrom (TVRMosaicMatrix * that);
	
		bool EqualsTo (TVRMosaicMatrix * that) const;
	
		void FreeAnyData(); // external
		bool NewSize (int anewcolsize, int anewrowsize); // external
	
		// destructor
	
		~ TVRMosaicMatrix(); // { this->FreeAnyData(); }
	
		// clone
	
		TVRMosaicMatrix * Clone() const;
	      // external
	
	}; // class


#endif