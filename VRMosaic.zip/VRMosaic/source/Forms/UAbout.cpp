//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UAbout.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTheAboutBox *TheAboutBox;
//---------------------------------------------------------------------------
__fastcall TTheAboutBox::TTheAboutBox(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTheAboutBox::theCloseBitBtnClick(TObject *Sender)
{
	this->Close();	
}
//---------------------------------------------------------------------------
