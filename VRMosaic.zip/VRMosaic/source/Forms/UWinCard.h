//---------------------------------------------------------------------------
#ifndef UWinCardH
#define UWinCardH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TYoureTheBestCard : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TBitBtn *TheCloseCardBtn;
	TImage *theBigWinnerImage;
	TBevel *Bevel1;
	TImage *Image2;
	TPanel *Panel2;
	void __fastcall TheCloseCardBtnClick(TObject *Sender);
	void __fastcall theBigWinnerImageClick(TObject *Sender);
	
private:	// User declarations
public:		// User declarations
	__fastcall TYoureTheBestCard(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TYoureTheBestCard *YoureTheBestCard;
//---------------------------------------------------------------------------
#endif
