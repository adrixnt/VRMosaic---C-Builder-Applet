//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------
USEFORM("..\source\Forms\UMainFrm.cpp", VRMosaicForm);
USEFORM("..\source\Forms\UAbout.cpp", TheAboutBox);
USEFORM("..\source\Forms\UWinCard.cpp", YoureTheBestCard);
USEFORM("..\source\Forms\UShowProgressFrm.cpp", VRMosaicResolverProgressForm);
//---------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->Title = "VRMosaic";
		Application->CreateForm(__classid(TVRMosaicForm), &VRMosaicForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
